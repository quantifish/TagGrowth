#' Function to return version number
#'
#' @export
#'
tagGrowth.version <- function()
{
    return("Version: 1.0\nCompile date: 2014-11-04\n")
}
